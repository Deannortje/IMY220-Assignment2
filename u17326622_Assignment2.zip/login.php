<?php
	// See all errors and warnings
	error_reporting(E_ALL);
	ini_set('error_reporting', E_ALL);

	$server = "localhost";
	$username = "root";
	$password = "";
	$database = "dbUser";
	$mysqli = mysqli_connect($server, $username, $password, $database);

	$email = isset($_POST["loginEmail"]) ? $_POST["loginEmail"] : false;
	$pass = isset($_POST["loginPass"]) ? $_POST["loginPass"] : false;	
	// if email and/or pass POST values are set, set the variables to those values, otherwise make them false
?>

<!DOCTYPE html>
<html>
<head>
	<title>IMY 220 - Assignment 2</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="style.css" />
	<meta charset="utf-8" />
	<meta name="author" content="Dean Nortje">
	<!-- Replace Name Surname with your name and surname -->
</head>
<body>
	<div class="container">
		<?php
			if($email && $pass){
				$query = "SELECT * FROM tbusers WHERE email = '$email' AND password = '$pass'";
				$res = $mysqli->query($query);
				if($row = mysqli_fetch_array($res)){
					echo 	"<table class='table table-bordered mt-3'>
								<tr>
									<td>Name</td>
									<td>" . $row['name'] . "</td>
								<tr>
								<tr>
									<td>Surname</td>
									<td>" . $row['surname'] . "</td>
								<tr>
								<tr>
									<td>Email Address</td>
									<td>" . $row['email'] . "</td>
								<tr>
								<tr>
									<td>Birthday</td>
									<td>" . $row['birthday'] . "</td>
								<tr>
							</table>
							
					";

					echo 	"<form method='POST' action='login.php' enctype='multipart/form-data'>
								<div class='form-group'>
								    <input type='hidden' name='loginEmail' value =".$_POST["loginEmail"]." />
				                    <input type='hidden' name='loginPass' value =".$_POST["loginPass"]." />
									<input type='file' class='form-control' name='picToUpload' id='picToUpload' /><br/>
									<input type='submit' class='btn btn-standard' value='Upload Image' name='submit' />
								</div>
						  	</form>";


                    //echo $_FILES["picToUpload"];
                    //echo $_POST['submit'];
                    if (isset($_POST["submit"])){
                        $userIdent = $row["user_id"];
                        $target_dir= "gallery/";
                        $uploadFile = $_FILES["picToUpload"];

                        if(($uploadFile["type"] == "image/jpg" || $uploadFile["type"] == "image/jpeg") && $uploadFile["size"] < 1048576)
                        {
                            if($uploadFile["error"] > 0)
                            {
                                echo "Error: " . $uploadFile["error"] . "<br/>";
                            }
                            else
                            {
                                $insertSQL = "INSERT INTO tbgallery (image_id,user_id,filename) VALUES (null,".$userIdent.",'".$uploadFile["name"]."')";
                                $r = mysqli_query($mysqli, $insertSQL);
                                move_uploaded_file($uploadFile["tmp_name"], $target_dir . $uploadFile["name"]);
                                //echo "Stored in: " . $target_dir . $uploadFile["name"];

                            }
                        }

                    }
                    else
                    {

                    }

                    echo "<div class='row imageGallery' >";

                            $userIdent = $row["user_id"];
                            $sql = "SELECT * FROM tbgallery WHERE user_id = ".$row["user_id"];
                            $result = $mysqli->query($sql);

                            if($result->num_rows> 0) {
                                // output data of each row
                                while ($row = $result->fetch_assoc()) {
                                echo "<div class='col-3' style='background-image: url(gallery/".$row["filename"].")'> </div>";
                                }
                            }
                    echo " </div> ";



                }
				else{
					echo 	'<div class="alert alert-danger mt-3" role="alert">
	  							You are not registered on this site!
	  						</div>';
				}
			} 
			else{
				echo 	'<div class="alert alert-danger mt-3" role="alert">
	  						Could not log you in
	  					</div>';
			}
		?>
	</div>
</body>
</html>